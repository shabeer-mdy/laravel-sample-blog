<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <h2><?php echo e(__('Blog Posts')); ?></h2>
                <hr>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 mt-2">
                        <div class="card">
                            <div class="card-header"><?php echo e($blog->title); ?></div>
                            <div class="card-body">
                                <p><?php echo e($blog->description); ?></p>
                            </div>
                            <div class="card-footer">
                                <small class="pull-right">
                                    <?php if($blog->user->avatar): ?>
                                    <img src="<?php echo e(asset('storage/'.$blog->user->avatar)); ?>" alt="" class="avatar"  style="width:20px; height:20px;">
                                    <?php endif; ?>
                                    <?php echo e($blog->user->name); ?> at <?php echo e($blog->created_at->format('m-d-Y')); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($blogs->isEmpty()): ?>
                        <div class="card">
                            <div class="card-body">
                                <p>
                                    There is no posts found at the moment.<a href="<?php echo e(route('blog.create')); ?>"> create post</a>
                                </p>
                            </div>
                        </div>
                        <?php endif; ?>
                </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\code\blog\resources\views\home.blade.php ENDPATH**/ ?>