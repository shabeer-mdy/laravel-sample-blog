<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('My Blogs')); ?></div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="col"><?php echo e($key+1); ?></th>
                                <th scope="col"><?php echo e($blog->title); ?></th>
                                <th scope="col">
                                    <a href="<?php echo e(route('blog.edit', $blog)); ?>">Edit</a>
                                    <a href="<?php echo e(route('blog.delete', $blog)); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('delete-form').submit();">
                                        <?php echo e(__('Delete')); ?>

                                    </a>

                                    <form id="delete-form" action="<?php echo e(route('blog.delete', $blog)); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                    </form>
                                    
                                </th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($blogs->isEmpty()): ?>
                            <tr>
                                <th colspan="3" align="center">
                                    No blog post found. <a href="<?php echo e(route('blog.create')); ?>">Create Blog</a>
                                </th>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\code\blog\resources\views\blog\index.blade.php ENDPATH**/ ?>