<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('My Blogs')); ?></div>
                <div class="card-body">
                    <?php if(!isset($blog)): ?>
                    <form role="form" action="<?php echo e(route('blog.create')); ?>" method="POST">
                    <?php else: ?>
                        <form role="form" action="<?php echo e(route('blog.edit', $blog)); ?>" method="POST">
                            <?php echo method_field('put'); ?>
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="blog-title">Title <em>*</em></label>
                          <input type="text" name="title" class="form-control" id="blog-title" aria-describedby="titleHelp" placeholder="Enter blog title" value="<?php echo e($blog->title ?? old('title')); ?>">
                          <?php if($errors->has('title')): ?>
                            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                           <?php endif; ?>
                        </div>
                        <div class="form-group">
                          <label for="blogDescription1">Description</label>
                          <textarea type="Description" name="description" class="form-control" id="blogDescription1" aria-describedby="descriptionHelp" placeholder="Description" row=10><?php echo e($blog->description ?? old('description')); ?></textarea>
                          <?php if($errors->has('description')): ?>
                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                           <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(route('blogs')); ?>" class="btn btn-warning">Cancel</a>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\code\blog\resources\views\blog\create.blade.php ENDPATH**/ ?>